---
name: antigravity-cli
description: "Operate the Antigravity CLI (agy): auth, plugins, sandbox."
version: 0.1.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [Coding-Agent, Antigravity, CLI, Auth, Plugins, Sandbox]
    related_skills: [claude-code, codex, hermes-agent]
---

# Antigravity CLI (`agy`)

Operator guide for the Antigravity CLI, invoked as `agy`. Run all `agy`
commands through the Hermes `terminal` tool; inspect its config and logs with
`read_file`.

## When to Use

- Installing, updating, or smoke-testing the `agy` binary
- Driving non-interactive `agy --print` / `agy -p` one-shots
- Debugging Antigravity auth, sandbox, permissions, or plugin state
- Delegating tasks to agy (Gemini Pro backend)

## Prerequisites

- The `agy` binary on PATH: `/Users/bytedance/.local/bin/agy`
- VPN required in China (geo-restricted, cosmetic "ineligible" warning is harmless)
- Google account `chargyzuo@gmail.com` has Gemini Pro

## How to Run

Invoke every `agy` command through the `terminal` tool:

```
terminal(command="agy --version")
terminal(command="agy --print 'Summarize the repo in 3 bullets'", workdir="/path/to/project")
```

For non-interactive one-shot prompts, use `script -q /dev/null` wrapper
(bubbletea requires /dev/tty):

```
terminal(command="script -q /dev/null agy -p 'your prompt' --print-timeout 60s")
```

## Core paths

- Binary: `/Users/bytedance/.local/bin/agy`
- App data dir: `~/.gemini/antigravity-cli/`
- Settings file: `~/.gemini/antigravity-cli/settings.json`
- Keybindings file: `~/.gemini/antigravity-cli/keybindings.json`
- Logs: `~/.gemini/antigravity-cli/log/cli-*.log`
- Conversations: `~/.gemini/antigravity-cli/conversations/`

## Auth

If auth breaks, clear credentials and re-authenticate (must be on VPN):

```
security delete-generic-password -s "gemini" -a "antigravity"
rm -rf ~/.gemini/antigravity-cli/cache/*
```

Then run `agy` in a real terminal to complete browser OAuth.

## MCP Integration

agy has its own MCP config at `~/.gemini/config/mcp_config.json`. Same format
as Hermes — share MCP servers by duplicating entries to both config files.

```bash
# Format for ~/.gemini/config/mcp_config.json
{
  "mcpServers": {
    "serverName": {
      "command": "python3",
      "args": ["/path/to/mcp_server.py"],
      "env": {}
    }
  }
}
```

Verify connected servers inside agy: `/mcp` slash command.

### Deep Mode (Thinking Models)

For complex analysis requiring deeper reasoning, use a thinking-capable model:

```bash
script -q /dev/null agy -p 'PROMPT' --print-timeout 120s --model "Claude Opus 4.6 (Thinking)"
```

Available models (`agy models`):
- Claude Opus 4.6 (Thinking) — best for deep reasoning
- Claude Sonnet 4.6 (Thinking) — good balance
- Gemini 3.5 Flash (Medium/High/Low) — fast, less deep
- Gemini 3.1 Pro (Low/High)
- GPT-OSS 120B (Medium)

## Delegation from Hermes

Use `delegate_task` to offload tasks to agy (Gemini Pro backend):

```
delegate_task(
  goal="Use agy to ...",
  context="Run via: script -q /dev/null agy -p 'PROMPT' --print-timeout 120s",
  toolsets=["terminal", "file"]
)
```

The child agent runs `script -q /dev/null agy -p "..."` and captures output.
See [references/delegation-mcp-pattern.md](references/delegation-mcp-pattern.md)
for the full architecture, when-to-delegate decision guide, and dual-MCP-config
maintenance notes.

## Pitfalls

- `agy` without arguments requires a real TTY (bubbletea). Use `script -q /dev/null agy -p "..."` from Hermes.
- The "Account ineligible: not currently available in your location" warning is cosmetic — API still works.
- Must be on VPN for Google API access.
- For complex multi-step tasks, prefer `delegate_task` with the agy backend.
- MCP configs are NOT shared between Hermes and agy — must maintain both files.
