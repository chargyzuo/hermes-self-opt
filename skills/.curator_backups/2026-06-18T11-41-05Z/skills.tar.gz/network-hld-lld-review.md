# network-hld-lld-review

## Trigger

Use this skill when the user asks to read, learn, summarize, review, or extract important information from network architecture documents, especially HLD, LLD, implementation guides, topology documents, routing designs, firewall policies, IP planning, VPN/direct-connect/cloud-network/IDC-network documents, or large Feishu-hosted project documents.

## Purpose

Help the user quickly learn large network architecture implementation documents. The goal is not a generic summary, but structured extraction of architecture, design intent, implementation details, key parameters, risks, dependencies, validation steps, rollback plans, and follow-up questions.

## Core Workflow

1. Ask the user for the Feishu document link, browser entry, or local exported file path.
2. Prefer downloading or exporting the source documents locally before analysis. If download/export is unavailable, use browser-based incremental reading.
3. Do not rely on a single long context window. Use chunked reading and persistent local notes.
4. Create a working directory named `network_arch_review/`.
5. Maintain these files:
   - `source_inventory.md`
   - `progress.md`
   - `architecture_notes.md`
   - `implementation_notes.md`
   - `config_notes.md`
   - `risk_notes.md`
   - `glossary.md`
   - `questions.md`
   - `final_learning_summary.md`

## Source Inventory

Before detailed reading, build a document map:

- List all HLD documents.
- List all LLD documents.
- List all attachments, diagrams, PDFs, Markdown files, Excel files, and embedded references.
- Record the relationship between HLD and LLD documents.
- Record document title, source URL/path, file type, owner if visible, and processing status.

## Chunking Rules

For large documents:

- Text / Markdown / Feishu docs: process by heading hierarchy or 2,000–4,000 Chinese characters per chunk.
- PDF: process 5–10 pages per chunk.
- Excel: first inspect workbook structure, sheet names, row/column counts, headers, and representative samples. Do not load large sheets directly into context.
- Diagrams: describe them in text, including components, connections, traffic direction, redundancy, security boundaries, and possible single points of failure.

After each chunk:

1. Write notes to the appropriate markdown files.
2. Update `progress.md`.
3. Record open questions in `questions.md`.
4. If context is getting full, stop and tell the user exactly where to continue.

## HLD Extraction Checklist

When reading HLD content, extract:

- Business background
- Design goals
- Scope and assumptions
- Overall network architecture
- Regions, sites, data centers, VPC/VNet, cloud accounts, tenants
- Network domains and segmentation
- North-south traffic path
- East-west traffic path
- Internet egress and ingress
- Hub-spoke, transit gateway, SD-WAN, MPLS, VPN, Direct Connect, ExpressRoute, Cloud Interconnect, or equivalent design
- Routing design
- BGP, OSPF, static routes, default routes
- Route propagation, route filtering, route priority, failover behavior
- Security boundary
- Firewall, ACL, Security Group, NACL, WAF, NAT, proxy, DDoS protection
- High availability and disaster recovery
- Active-active / active-standby design
- Capacity and performance assumptions
- Bandwidth, throughput, PPS, connections, scaling assumptions
- Key design decisions and rationale
- Risks, constraints, dependencies, and known gaps

## LLD Extraction Checklist

When reading LLD content, extract:

- Concrete topology
- Device, gateway, interface, subnet, VLAN, VRF, VPC/VNet, AZ, region mapping
- IP address planning
- BGP ASN, peer IP, route-map, prefix-list, community, MED, local preference
- OSPF area, metric, redistribution if applicable
- Static routes and default routes
- NAT rules
- Firewall policies
- ACL / Security Group / NACL rules
- DNS, DHCP, NTP, proxy, load balancer, tunnel, VPN, IPSec parameters
- Implementation sequence
- Pre-checks
- Change steps
- Validation commands
- Connectivity tests
- Route table verification
- Failover tests
- Performance tests
- Security policy verification
- Rollback plan
- Monitoring metrics
- Alerting, logs, runbook, and troubleshooting methods

## Excel Handling

For Excel files:

1. Inspect workbook structure first.
2. List all sheets.
3. For each sheet, identify:
   - Purpose
   - Headers
   - Key fields
   - Row/column count
   - IPs, routes, ACLs, firewall rules, device inventory, change tasks
4. For large sheets, use scripts or filters to summarize:
   - Unique networks
   - Route counts
   - Policy counts
   - Duplicate/conflicting IP ranges
   - Missing fields
   - Suspicious broad rules
5. Only bring small representative samples into LLM context.

## Diagram Handling

For architecture diagrams, convert the diagram into a textual architecture description:

- Components
- Connections
- Traffic direction
- Network zones
- Security boundaries
- Redundancy pairs
- Failover path
- Control plane vs data plane
- Possible single points of failure
- Unclear labels or missing details

## Per-Document Mini Summary

After each HLD or LLD document, generate a mini-summary with:

1. The 10 most important things the user must understand.
2. Key parameters to remember.
3. Important architecture decisions.
4. Main implementation steps.
5. Main risks and dependencies.
6. 5–10 questions the user should ask the project or network team.
7. Gaps between HLD and LLD.

## Final Output

After all documents are processed, create `final_learning_summary.md` with:

# One-Page Learning Summary

- Background
- Goal
- Final architecture
- Key traffic paths
- Key routing and security design
- Most important implementation details
- Major risks
- Recommended next actions

# Detailed Learning Summary

## 1. Document Scope

## 2. Overall Network Architecture

## 3. HLD Core Design

## 4. LLD Implementation Details

## 5. Key Traffic Paths

## 6. Routing Design

## 7. Security Policy Design

## 8. IP / Subnet / VLAN / VRF / VPC Planning

## 9. High Availability and Failover

## 10. Implementation Plan

## 11. Validation and Acceptance Tests

## 12. Rollback Plan

## 13. Monitoring and Operations

## 14. Key Parameter Table

## 15. Risk Register

## 16. Glossary

## 17. Questions for Network / Project Team

## 18. What the User Should Learn and Remember

## Behavior Rules

- Be precise and technical.
- Do not produce a shallow generic summary.
- Always preserve key network parameters.
- Never skip routing, security, HA, rollback, or validation sections.
- If information is missing, explicitly record it in `questions.md`.
- If documents are too large, pause after saving progress and explain the exact continuation point.
